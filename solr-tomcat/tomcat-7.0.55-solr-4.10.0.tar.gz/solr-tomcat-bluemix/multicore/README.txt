This is an alternative setup structure to support multiple cores.

To run this configuration, start jetty in the example/ directory using:

java -Dsolr.solr.home=multicore -jar start.jar

For general examples on standard solr configuration, see the "solr" directory.
